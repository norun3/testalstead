﻿/**
 * 階調を反転して画像を描画するオブジェクト
*/
class InvertedDrawnObject2D extends asd.TextureObject2D
{
	private static java.lang.String shader2d_dx_ps = ""+
"Texture2D g_texture : register( t0 );"+
"SamplerState g_sampler : register( s0 );"+
""+
"struct PS_Input"+
"{"+
"	float4 SV_Position : SV_POSITION;"+
"	float4 Position : POSITION;"+
"	float2 UV : UV;"+
"	float4 Color : COLOR;"+
"};"+
""+
"float4 main( const PS_Input Input ) : SV_Target"+
"{"+
"	float4 color = g_texture.Sample(g_sampler, Input.UV);"+
"	return float4( 1.0 - color.x, 1.0 - color.y, 1.0 - color.z, color.w);"+
"}"+
""+
"";
	private static java.lang.String shader2d_gl_ps = ""+
"uniform sampler2D g_texture;"+
""+
"in vec4 inPosition;"+
"in vec2 inUV;"+
"in vec4 inColor;"+
""+
"out vec4 outOutput;"+
""+
"void main()"+
"{"+
"	vec4 color = texture(g_texture, inUV.xy);"+
"	outOutput = vec4( 1.0 - color.x, 1.0 - color.y, 1.0 - color.z, color.w);"+
"}"+
""+
"";
	private asd.Shader2D shader;
	private asd.Material2D material2d;
	private asd.Texture2D texture;
	protected void OnDrawAdditionally()
	{
		// 画像を描画する。
		DrawSpriteWithMaterialAdditionally(new asd.Vector2DF(100, 100), new asd.Vector2DF(400, 100), new asd.Vector2DF(400, 400), new asd.Vector2DF(100, 400), new asd.Color(255, 255, 255, 255), new asd.Color(255, 255, 255, 255), new asd.Color(255, 255, 255, 255), new asd.Color(255, 255, 255, 255), new asd.Vector2DF(0.0f, 0.0f), new asd.Vector2DF(1.0f, 0.0f), new asd.Vector2DF(1.0f, 1.0f), new asd.Vector2DF(0.0f, 1.0f), material2d, asd.AlphaBlendMode.Blend, 			0);
	}
	public InvertedDrawnObject2D()
	{
		// シェーダーをHLSL/GLSLから生成する。
		if((asd.Engine.getGraphics().getGraphicsDeviceType() == asd.GraphicsDeviceType.DirectX11))
		{
			shader = asd.Engine.getGraphics().CreateShader2D(shader2d_dx_ps);
		}
		else
		{
			if((asd.Engine.getGraphics().getGraphicsDeviceType() == asd.GraphicsDeviceType.OpenGL))
			{
				shader = asd.Engine.getGraphics().CreateShader2D(shader2d_gl_ps);
			}
		}

		// シェーダーからマテリアルを生成する。
		material2d = asd.Engine.getGraphics().CreateMaterial2D(shader);

		// 画像を読み込む。
		texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// 画像を設定する。
		material2d.SetTexture2D("g_texture", texture);
		material2d.SetTextureFilterType("g_texture", asd.TextureFilterType.Linear);
		material2d.SetTextureWrapType("g_texture", asd.TextureWrapType.Repeat);
	}
}
