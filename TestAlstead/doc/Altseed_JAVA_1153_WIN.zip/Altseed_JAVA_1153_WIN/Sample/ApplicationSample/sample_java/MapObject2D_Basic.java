﻿/**
 * マップを表示するサンプル。
*/
class MapObject2D_Basic 
{
	public java.lang.String getDescription() {
		return "マップチップを並べて描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "マップチップの描画";
	}
	public java.lang.String getClassName() {
		return "MapObject2D_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("MapObject2D_Basic", 640, 480, new asd.EngineOption());

		// マップオブジェクトを生成する。
		asd.MapObject2D mapObject = new asd.MapObject2D();

		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Chip1.png");

		// マップオブジェクトに16*12=184個のチップを登録する。
		for(int i = 0; (i < 16); ++i)
		{
			for(int j = 0; (j < 12); ++j)
			{
				// チップを生成する。
				asd.Chip2D chip = new asd.Chip2D();

				// チップにテクスチャを設定する。
				chip.setTexture(texture);

				// チップの描画先を指定する。
				chip.setPosition(new asd.Vector2DF((i * 40), (j * 40)));

				// マップオブジェクトにチップを追加する。
				mapObject.AddChip(chip);
			}
		}

		// レイヤーにマップオブジェクトを追加する。
		asd.Engine.AddObject2D(mapObject);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
