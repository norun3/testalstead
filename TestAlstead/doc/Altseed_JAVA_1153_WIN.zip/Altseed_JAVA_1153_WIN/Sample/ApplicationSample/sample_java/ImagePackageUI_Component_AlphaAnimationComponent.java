﻿class ImagePackageUI_Component_AlphaAnimationComponent extends asd.Object2DComponent
{
	private int time = 0;
	protected void OnUpdate()
	{
		// アルファ値をsinカーブでアニメーションするようにする。
		int alpha = (int)(((float)(java.lang.Math.sin((time / 20.0f)) + 1.0f) / 2.0f ) * 255);
		asd.TextureObject2D owner = (asd.TextureObject2D)getOwner();
		owner.setColor(new asd.Color(255, 255, 255, alpha));
		time++;
	}
}
