﻿/**
 * ゲームの挙動を描画するレイヤー
*/
class Pause_Basic_MainLayer extends asd.Layer2D
{
	private asd.TextureObject2D obj = null;
	protected void OnUpdated()
	{
		// スペースが押されたら、ポーズレイヤーを追加する。
		if((asd.Engine.getKeyboard().GetKeyState(asd.Keys.Space) == asd.KeyState.Push))
		{
			Pause_Basic_PauseLayer pauseLayer = new Pause_Basic_PauseLayer();
			getScene().AddLayer(pauseLayer);
		}

		// 画像を回転させる。
		obj.setAngle((obj.getAngle() + 1.0f));
	}
	public Pause_Basic_MainLayer()
	{
		// 画像を表示するオブジェクトを生成する。
		obj = new asd.TextureObject2D();
		obj.setTexture(asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png"));
		obj.setPosition(new asd.Vector2DF(320, 240));
		obj.setCenterPosition(new asd.Vector2DF((obj.getTexture().getSize().X / 2), (obj.getTexture().getSize().Y / 2)));
		AddObject(obj);
	}
}
