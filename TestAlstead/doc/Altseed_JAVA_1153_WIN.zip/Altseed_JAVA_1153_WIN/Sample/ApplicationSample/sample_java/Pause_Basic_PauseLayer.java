﻿/**
 * ポーズを実行するレイヤー
*/
class Pause_Basic_PauseLayer extends asd.Layer2D
{
	protected void OnAdded()
	{
		// ポーズ以外のレイヤーの更新を停止する。
		for(asd.Layer layer: getScene().getLayers())
		{
			if((layer != this))
			{
				layer.setIsUpdated(false);
			}
		}

		// ポーズを表示するオブジェクトを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();
		obj.setTexture(asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Pause1.png"));
		AddObject(obj);
	}
	protected void OnUpdated()
	{
		// スペースが押されたら、他のレイヤーの更新を再開して、ポーズレイヤーを破棄する。
		if((asd.Engine.getKeyboard().GetKeyState(asd.Keys.Space) == asd.KeyState.Push))
		{
			for(asd.Layer layer: getScene().getLayers())
			{
				layer.setIsUpdated(true);
			}
			Dispose();
		}
	}
}
