﻿/**
 * 階調を反転するポストエフェクトのサンプル。
*/
class CustomPostEffect_Invert 
{
	public java.lang.String getDescription() {
		return "画面の色の階調を反転するポストエフェクトのサンプル。";
	}
	public java.lang.String getTitle() {
		return "反転ポストエフェクト";
	}
	public java.lang.String getClassName() {
		return "CustomPostEffect_Invert";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("CustomPostEffect_Invert", 640, 480, new asd.EngineOption());

		// シーン、レイヤー、画像を表示するオブジェクトを生成する。
		asd.Scene scene = new asd.Scene();
		asd.Layer2D layer = new asd.Layer2D();
		asd.TextureObject2D obj = new asd.TextureObject2D();
		obj.setTexture(asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png"));

		// シーンを変更し、そのシーンにレイヤーを追加し、そのレイヤーにオブジェクトを追加する。
		asd.Engine.ChangeScene(scene);
		scene.AddLayer(layer);
		layer.AddObject(obj);

		// レイヤーにポストエフェクトを適用する。
		layer.AddPostEffect(new CustomPostEffect_InvertPostEffect());

		while(asd.Engine.DoEvents())
		{
			asd.Engine.Update();
		}
		

		asd.Engine.Terminate();
	}
}
