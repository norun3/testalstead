﻿/**
 * ポーズのサンプル。
*/
class Pause_Basic 
{
	public java.lang.String getDescription() {
		return "レイヤーの処理を一時停止するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "ポーズ";
	}
	public java.lang.String getClassName() {
		return "Pause_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Pause_Basic", 640, 480, new asd.EngineOption());

		// シーンを生成する
		asd.Scene scene = new asd.Scene();

		// ゲームの挙動を描画するレイヤーを生成する
		Pause_Basic_MainLayer layer = new Pause_Basic_MainLayer();

		// シーンにレイヤーを追加する
		scene.AddLayer(layer);

		// シーンを切り替える
		asd.Engine.ChangeScene(scene);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
