﻿/**
 * 階調を反転させるポストエフェクト
*/
class CustomPostEffect_InvertPostEffect extends asd.PostEffect
{
	private static java.lang.String shader2d_dx_ps = ""+
"Texture2D g_texture : register( t0 );"+
"SamplerState g_sampler : register( s0 );"+
""+
"struct PS_Input"+
"{"+
"	float4 SV_Position : SV_POSITION;"+
"	float4 Position : POSITION;"+
"	float2 UV : UV;"+
"	float4 Color : COLOR;"+
"};"+
""+
"float4 main( const PS_Input Input ) : SV_Target"+
"{"+
"	float4 color = g_texture.Sample(g_sampler, Input.UV);"+
"	return float4( 1.0 - color.x, 1.0 - color.y, 1.0 - color.z, color.w);"+
"}"+
""+
"";
	private static java.lang.String shader2d_gl_ps = ""+
"uniform sampler2D g_texture;"+
""+
"in vec4 inPosition;"+
"in vec2 inUV;"+
"in vec4 inColor;"+
""+
"out vec4 outOutput;"+
""+
"void main()"+
"{"+
"	vec4 color = texture(g_texture, inUV.xy);"+
"	outOutput = vec4( 1.0 - color.x, 1.0 - color.y, 1.0 - color.z, color.w);"+
"}"+
""+
"";
	private asd.Shader2D shader;
	private asd.Material2D material2d;
	protected void OnDraw(asd.RenderTexture2D dst, asd.RenderTexture2D src)
	{
		// マテリアルを経由してシェーダー内のg_texture変数に画面の画像(src)を入力する。
		material2d.SetTexture2D("g_texture", src);

		// 出力画像(dst)に指定したマテリアルで描画する。
		DrawOnTexture2DWithMaterial(dst, material2d);
	}
	public CustomPostEffect_InvertPostEffect()
	{
		// シェーダーをHLSL/GLSLから生成する。
		if((asd.Engine.getGraphics().getGraphicsDeviceType() == asd.GraphicsDeviceType.DirectX11))
		{
			shader = asd.Engine.getGraphics().CreateShader2D(shader2d_dx_ps);
		}
		else
		{
			if((asd.Engine.getGraphics().getGraphicsDeviceType() == asd.GraphicsDeviceType.OpenGL))
			{
				shader = asd.Engine.getGraphics().CreateShader2D(shader2d_gl_ps);
			}
		}

		// シェーダーからマテリアルを生成する。
		material2d = asd.Engine.getGraphics().CreateMaterial2D(shader);
	}
}
