﻿class Action2D_Camera 
{
	public java.lang.String getDescription() {
		return "アクションゲームでカメラがキャラクターを追うサンプルです。";
	}
	public java.lang.String getTitle() {
		return "アクションゲームのカメラ";
	}
	public java.lang.String getClassName() {
		return "Action2D_Camera";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Action2D_Camera", 640, 480, new asd.EngineOption());

		// カメラを設定する。
		asd.CameraObject2D camera = new asd.CameraObject2D();

		camera.setSrc(new asd.RectI(0, 0, 640, 480));
		camera.setDst(new asd.RectI(0, 0, 640, 480));

		// エンジンにカメラオブジェクトを追加する。
		asd.Engine.AddObject2D(camera);

		// マップオブジェクトを生成する。
		asd.MapObject2D mapObject = new asd.MapObject2D();

		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Chip1.png");

		// マップオブジェクトに50*50=2500個のチップを登録する。
		for(int i = 0; (i < 50); ++i)
		{
			for(int j = 0; (j < 50); ++j)
			{
				// チップを生成する。
				asd.Chip2D chip = new asd.Chip2D();

				// チップにテクスチャを設定する。
				chip.setTexture(texture);

				// チップの描画先を指定する。
				chip.setPosition(new asd.Vector2DF(((i * 40 ) - 1000), ((j * 40 ) - 1000)));

				// マップオブジェクトにチップを追加する。
				mapObject.AddChip(chip);
			}
		}

		// マップオブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(mapObject);

		// キャラクターを設定する。
		asd.TextureObject2D charactor = new asd.TextureObject2D();

		// キャラクターの画像を読み込む。
		charactor.setTexture(asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Character1.png"));

		// キャラクターをエンジンに追加する。
		asd.Engine.AddObject2D(charactor);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// キャラクターを移動させる。
			if((asd.Engine.getKeyboard().GetKeyState(asd.Keys.Up) == asd.KeyState.Hold))
			{
				charactor.setPosition(asd.Vector2DF.Add(charactor.getPosition(), new asd.Vector2DF(0, -2)));
			}
			if((asd.Engine.getKeyboard().GetKeyState(asd.Keys.Down) == asd.KeyState.Hold))
			{
				charactor.setPosition(asd.Vector2DF.Add(charactor.getPosition(), new asd.Vector2DF(0, +2)));
			}
			if((asd.Engine.getKeyboard().GetKeyState(asd.Keys.Left) == asd.KeyState.Hold))
			{
				charactor.setPosition(asd.Vector2DF.Add(charactor.getPosition(), new asd.Vector2DF(-2, 0)));
			}
			if((asd.Engine.getKeyboard().GetKeyState(asd.Keys.Right) == asd.KeyState.Hold))
			{
				charactor.setPosition(asd.Vector2DF.Add(charactor.getPosition(), new asd.Vector2DF(+2, 0)));
			}

			// カメラをキャラクターの位置に合わせる。
			asd.RectI pos = camera.getSrc();
			pos.X = ((int)charactor.getPosition().X - (640  / 2));
			pos.Y = ((int)charactor.getPosition().Y - (480  / 2));
			camera.setSrc(pos);

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
