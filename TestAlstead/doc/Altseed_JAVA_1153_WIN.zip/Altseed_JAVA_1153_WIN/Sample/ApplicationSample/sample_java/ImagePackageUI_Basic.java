﻿/**
 * ImagePackageを用いてUIを配置するサンプル。
*/
class ImagePackageUI_Basic 
{
	public java.lang.String getDescription() {
		return "ImagePackageを用いてUIを配置するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "ImagePackage";
	}
	public java.lang.String getClassName() {
		return "ImagePackageUI_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("ImagePackageUI_Basic", 640, 480, new asd.EngineOption());

		// イメージパッケージを読み込む
		asd.ImagePackage imagePackage = asd.Engine.getGraphics().CreateImagePackage("Data/ImagePackage/UI.aip");

		for(int i = 0; (i < imagePackage.getImageCount()); i++)
		{
			// テクスチャを取り出す
			asd.Texture2D texture = imagePackage.GetImage(i);
			asd.RectI area = imagePackage.GetImageArea(i);

			// テクスチャをオブジェクトとして追加する
			asd.TextureObject2D textureObject2D = new asd.TextureObject2D();
			textureObject2D.setTexture(texture);
			textureObject2D.setPosition(new asd.Vector2DF(area.X, area.Y));
			asd.Engine.AddObject2D(textureObject2D);
		}

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
