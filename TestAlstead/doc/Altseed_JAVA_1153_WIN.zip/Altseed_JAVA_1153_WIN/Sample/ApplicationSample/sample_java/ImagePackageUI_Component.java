﻿/**
 * ImagePackageを用いてUIを配置して、特定の名前の画像をアニメーションさせるサンプル。
*/
class ImagePackageUI_Component 
{
	public java.lang.String getDescription() {
		return "ImagePackageを用いてUIを配置し、その際に特定の名前の画像を\nアニメーションさせるサンプル。";
	}
	public java.lang.String getTitle() {
		return "ImagePackageとアニメーション";
	}
	public java.lang.String getClassName() {
		return "ImagePackageUI_Component";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("ImagePackageUI_Component", 640, 480, new asd.EngineOption());

		// イメージパッケージを読み込む
		asd.ImagePackage imagePackage = asd.Engine.getGraphics().CreateImagePackage("Data/ImagePackage/UI.aip");

		for(int i = 0; (i < imagePackage.getImageCount()); i++)
		{
			// テクスチャを取り出す
			asd.Texture2D texture = imagePackage.GetImage(i);
			asd.RectI area = imagePackage.GetImageArea(i);

			// テクスチャをオブジェクトとして追加する
			asd.TextureObject2D textureObject2D = new asd.TextureObject2D();
			textureObject2D.setTexture(texture);
			textureObject2D.setPosition(new asd.Vector2DF(area.X, area.Y));
			asd.Engine.AddObject2D(textureObject2D);

			// Background_Lightという名称の画像にコンポーネントを適用する。
			if((imagePackage.GetImageName(i).equals("Background_Light")))
			{
				textureObject2D.setAlphaBlend(asd.AlphaBlendMode.Add);
				textureObject2D.AddComponent(new ImagePackageUI_Component_AlphaAnimationComponent(), "AlphaAnimation");
			}
		}

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
