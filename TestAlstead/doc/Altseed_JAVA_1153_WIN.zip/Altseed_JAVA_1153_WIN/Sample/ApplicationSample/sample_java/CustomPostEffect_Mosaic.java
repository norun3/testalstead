﻿/**
 * 一部の領域にモザイクをかけるポストエフェクトのサンプル。
*/
class CustomPostEffect_Mosaic 
{
	public java.lang.String getDescription() {
		return "一部の領域にモザイクをかけるポストエフェクトのサンプルです。";
	}
	public java.lang.String getTitle() {
		return "モザイク ポストエフェクト";
	}
	public java.lang.String getClassName() {
		return "CustomPostEffect_Mosaic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("CustomPostEffect_Mosaic", 640, 480, new asd.EngineOption());

		// シーン、レイヤー、画像を表示するオブジェクトを生成する。
		asd.Scene scene = new asd.Scene();
		asd.Layer2D layer = new asd.Layer2D();
		asd.TextureObject2D obj = new asd.TextureObject2D();
		obj.setTexture(asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png"));

		// シーンを変更し、そのシーンにレイヤーを追加し、そのレイヤーにオブジェクトを追加する。
		asd.Engine.ChangeScene(scene);
		scene.AddLayer(layer);
		layer.AddObject(obj);

		// レイヤーにポストエフェクトを適用する。
		layer.AddPostEffect(new CustomPostEffect_MosaicPostEffect());

		while(asd.Engine.DoEvents())
		{
			asd.Engine.Update();
		}
		

		asd.Engine.Terminate();
	}
}
