﻿/**
 * 専用のシェーダーを使用してスプライトを追加で描画するサンプル。
*/
class DrawAdditionally2D_Material 
{
	public java.lang.String getDescription() {
		return "専用のシェーダーを使用してスプライトを追加で描画するサンプル。";
	}
	public java.lang.String getTitle() {
		return "追加描画(シェーダー)";
	}
	public java.lang.String getClassName() {
		return "DrawAdditionally2D_Material";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("DrawAdditionally2D_Material", 640, 480, new asd.EngineOption());

		// シーン、レイヤー、画像を表示するオブジェクトを生成する。
		asd.Scene scene = new asd.Scene();
		asd.Layer2D layer = new asd.Layer2D();
		InvertedDrawnObject2D obj = new InvertedDrawnObject2D();

		// シーンを変更し、そのシーンにレイヤーを追加し、そのレイヤーにオブジェクトを追加する。
		asd.Engine.ChangeScene(scene);
		scene.AddLayer(layer);
		layer.AddObject(obj);

		while(asd.Engine.DoEvents())
		{
			asd.Engine.Update();
		}
		

		asd.Engine.Terminate();
	}
}
