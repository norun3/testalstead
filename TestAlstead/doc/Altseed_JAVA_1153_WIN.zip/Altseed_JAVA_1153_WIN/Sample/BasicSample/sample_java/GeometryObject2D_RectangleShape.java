﻿/**
 * 矩形を表示するサンプル。
*/
class GeometryObject2D_RectangleShape 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "GeometryObject2D_RectangleShape";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("GeometryObject2D_RectangleShape", 640, 480, new asd.EngineOption());

		// 図形描画オブジェクトのインスタンスを生成する。
		asd.GeometryObject2D geometryObj = new asd.GeometryObject2D();

		// 図形描画クラスのインスタンスをエンジンに追加する。
		asd.Engine.AddObject2D(geometryObj);

		// 矩形の図形クラスのインスタンスを生成する。
		asd.RectangleShape rect = new asd.RectangleShape();

		// 矩形の描画範囲を指定する。
		rect.setDrawingArea(new asd.RectF(10, 210, 300, 200));

		// 矩形を描画する図形として設定しする。
		geometryObj.setShape(rect);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
