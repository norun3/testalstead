﻿/**
 * 画像を一部切り出して表示するサンプル。
*/
class TextureObject2D_Src 
{
	public java.lang.String getDescription() {
		return "画像の一部を切り出して描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "画像の切り抜き";
	}
	public java.lang.String getClassName() {
		return "TextureObject2D_Src";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("TextureObject2D_Src", 640, 480, new asd.EngineOption());

		// 画像を読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// 画像描画オブジェクトのインスタンスを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();

		// 描画される画像を設定する。
		obj.setTexture(texture);

		// 描画位置を指定する。
		obj.setPosition(new asd.Vector2DF(50, 50));

		// 切り出す領域を指定する。
		obj.setSrc(new asd.RectF(150, 150, 200, 200));

		// 画像描画オブジェクトのインスタンスをエンジンに追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
