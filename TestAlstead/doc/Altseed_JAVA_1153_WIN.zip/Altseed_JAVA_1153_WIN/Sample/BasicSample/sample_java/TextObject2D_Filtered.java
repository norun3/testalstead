﻿/**
 * 文字列をギザギザを防いで回転させて表示するサンプル。
*/
class TextObject2D_Filtered 
{
	public java.lang.String getDescription() {
		return "文字列の回転をしたときにギザギザが発生するのを防ぐ機能を使ったサンプルです。";
	}
	public java.lang.String getTitle() {
		return "回転した文字列の滑らかな描画";
	}
	public java.lang.String getClassName() {
		return "TextObject2D_Filtered";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("TextObject2D_Filter", 640, 480, new asd.EngineOption());


		// フォントと文字描画オブジェクトの設定を行う。
		asd.Font edgeFont = asd.Engine.getGraphics().CreateFont("Data/Font/Font1.aff");
		asd.TextObject2D edgeObj = new asd.TextObject2D();
		edgeObj.setFont(edgeFont);
		edgeObj.setPosition(new asd.Vector2DF(100, 100));

		// 回転角を設定する。
		edgeObj.setAngle(30);

		// 描画のフィルタを線形補間にすることによって、描画時に境界がギザギザにならないように設定する。
		edgeObj.setTextureFilterType(asd.TextureFilterType.Linear);

		edgeObj.setText("ギザギザをなくした文字列の描画");

		// 文字描画オブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(edgeObj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
