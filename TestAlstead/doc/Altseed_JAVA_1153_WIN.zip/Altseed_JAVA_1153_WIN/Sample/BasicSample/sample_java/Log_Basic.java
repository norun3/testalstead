﻿class Log_Basic 
{
	public java.lang.String getDescription() {
		return "ログファイルにログを出力するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "ログ出力";
	}
	public java.lang.String getClassName() {
		return "Log_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Log", 640, 480, new asd.EngineOption());

		// Engineの標準のロガーを使う（Log.htmlに出力される）
		asd.Log logger = asd.Engine.getLogger();

		// ヘッダー文字列を出力する
		logger.WriteHeading("サンプル出力");

		// 文字列を出力する
		logger.Write("文字列");

		// 改行付きで文字列を出力する
		logger.WriteLine("文字列＋改行");

		// 山括弧のエスケープもされる
		logger.WriteLine("<文字列>");

		// 水平線(<hr/>)
		logger.WriteHorizontalRule();

		// 強調された文字列を出力する
		logger.WriteLineStrongly("強調文字列");


		// メッセージ用の文字列を用意する。TextObject2D_DynamicFontのサンプルを参照
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 26, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));
		asd.TextObject2D obj = new asd.TextObject2D();
		obj.setFont(font);
		obj.setPosition(new asd.Vector2DF(0, 0));
		obj.setText("Log.htmlにログを出力しました。\nウィンドウを閉じる前に確認してください。");
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
