﻿class Dispose_Layer2D_MessageLayer extends asd.Layer2D
{
	protected void OnDispose()
	{
		System.out.println("MessageLayer.OnDispose");
	}
}
