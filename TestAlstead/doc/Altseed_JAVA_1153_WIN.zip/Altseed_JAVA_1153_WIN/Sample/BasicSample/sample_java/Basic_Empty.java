﻿/**
 * 空のウインドウを表示するサンプル。
*/
class Basic_Empty 
{
	public java.lang.String getDescription() {
		return "空のウインドウを表示するサンプル。";
	}
	public java.lang.String getTitle() {
		return "Altseedの基本";
	}
	public java.lang.String getClassName() {
		return "Basic_Empty";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Empty", 640, 480, new asd.EngineOption());

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
