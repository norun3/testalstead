﻿/**
 * エフェクトを再生するサンプル。
*/
class EffectObject2D_Basic 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "EffectObject2D_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("EffectObject2D_Basic", 640, 480, new asd.EngineOption());

		// エフェクトを読み込む。
		asd.Effect effect = asd.Engine.getGraphics().CreateEffect("Data/Effect/magic.efk");

		// エフェクトオブジェクトを生成する。
		asd.EffectObject2D effectObj = new asd.EffectObject2D();

		// エフェクトオブジェクトのインスタンスをエンジンに追加する。
		asd.Engine.AddObject2D(effectObj);

		// エフェクトを設定する。
		effectObj.setEffect(effect);

		// エフェクトの位置、大きさを指定する。
		effectObj.setPosition(new asd.Vector2DF(320, 240));
		effectObj.setScale(new asd.Vector2DF(50, 50));

		// エフェクトを再生する。
		effectObj.Play();

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
