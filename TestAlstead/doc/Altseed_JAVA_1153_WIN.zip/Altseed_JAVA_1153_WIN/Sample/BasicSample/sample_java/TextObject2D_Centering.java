﻿/**
 * 文字列を中央揃えで描画するサンプル
*/
class TextObject2D_Centering 
{
	public java.lang.String getDescription() {
		return "文字列を中央揃えで描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "文字列の中央揃え";
	}
	public java.lang.String getClassName() {
		return "TextObject2D_Centering";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("TextObject2D_Centering", 640, 480, new asd.EngineOption());

		// フォントを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 40, new asd.Color(255, 0, 0, 255), 1, new asd.Color(255, 255, 255, 255));

		// 文字描画オブジェクトを生成する。
		asd.TextObject2D obj = new asd.TextObject2D();

		// 描画に使うフォントを設定する。
		obj.setFont(font);

		// 描画する文字列を設定する。
		java.lang.String str = "中央揃えサンプル";
		obj.setText(str);

		// 文字列を描画したときの縦横の大きさを取得する。
		asd.Vector2DI size = font.CalcTextureSize(str, asd.WritingDirection.Horizontal);

		// 描画位置を指定する。（画面中心が基準）
		asd.Vector2DF pos = new asd.Vector2DF((asd.Engine.getWindowSize().X - size.X), (asd.Engine.getWindowSize().Y - size.Y));
		obj.setPosition(asd.Vector2DF.DivideByScalar(pos, 2.0f));

		// 文字描画オブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
