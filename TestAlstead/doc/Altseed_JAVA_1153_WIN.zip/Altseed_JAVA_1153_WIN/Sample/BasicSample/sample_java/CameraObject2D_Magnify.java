﻿/**
 * カメラを用いて描画空間の一部を虫眼鏡のような表示で描画するサンプル。
*/
public class CameraObject2D_Magnify 
{
	public java.lang.String getDescription() {
		return "カメラを用いて描画空間の一部を虫眼鏡のように拡大して描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "カメラによる拡大描画";
	}
	public java.lang.String getClassName() {
		return "CameraObject2D_Magnify";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("CameraObject2D_Magnify", 640, 480, new asd.EngineOption());


		// 画像を読み込み、画像描画オブジェクトを設定する。
		// 画像を読み込み、画像描画オブジェクトを設定する。

		asd.Texture2D tex0 = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Sample1.png");
		asd.TextureObject2D obj0 = new asd.TextureObject2D();
		obj0.setTexture(tex0);
		obj0.setCenterPosition(new asd.Vector2DF(256, 256));
		obj0.setPosition(new asd.Vector2DF(320, 240));
		obj0.setScale(new asd.Vector2DF(0.5f, 0.5f));

		asd.Engine.AddObject2D(obj0);

		// 一つ目の画面全体を写すカメラ。(オブジェクトをそのまま描画する。)
		// 一つ目の画面全体を写すカメラ。(オブジェクトをそのまま描画する。)

		asd.CameraObject2D camera1 = new asd.CameraObject2D();
		camera1.setSrc(new asd.RectI(0, 0, 640, 480));
		camera1.setDst(new asd.RectI(0, 0, 640, 480));
		asd.Engine.AddObject2D(camera1);

		// 二つ目のマウスポインタの周辺を拡大して表示するカメラ。
		asd.CameraObject2D camera2 = new asd.CameraObject2D();
		asd.Engine.AddObject2D(camera2);

		// フレーム用画像を読み込む。
		asd.TextureObject2D frame = new asd.TextureObject2D();
		asd.Texture2D tex = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Frame.png");
		frame.setTexture(tex);
		frame.setCenterPosition(new asd.Vector2DF(55.0f, 55.0f));

		asd.Engine.AddObject2D(frame);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// マウスポインタの位置を取得する。
			asd.Vector2DF pos = asd.Engine.getMouse().getPosition();

			// 拡大用カメラの描画元を指定する。
			camera2.setSrc(new asd.RectI(((int)pos.X - 25), ((int)pos.Y - 25), 50, 50));

			// ポインタを中心に100x100の拡大画像を表示する。
			camera2.setDst(new asd.RectI(((int)pos.X - 50), ((int)pos.Y - 50), 100, 100));

			// フレーム画像の描画中心をマウスポインタの位置に合わせる。
			frame.setPosition(pos);

			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
