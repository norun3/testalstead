﻿class Dispose_Object2D_MessageObject extends asd.TextureObject2D
{
	protected void OnDispose()
	{
		System.out.println("MessageObject.OnDispose");
	}
}
