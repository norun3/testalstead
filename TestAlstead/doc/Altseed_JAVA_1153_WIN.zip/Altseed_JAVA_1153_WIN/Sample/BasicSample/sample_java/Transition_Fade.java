﻿class Transition_Fade 
{
	public java.lang.String getDescription() {
		return "フェードイン・フェードアウトを用いてシーン遷移をするサンプルです。";
	}
	public java.lang.String getTitle() {
		return "フェードイン・フェードアウト";
	}
	public java.lang.String getClassName() {
		return "Transition_Fade";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Transition_Fade", 640, 480, new asd.EngineOption());

		// シーンのインスタンスを生成する。
		Transition_Fade_Scene1 scene = new Transition_Fade_Scene1();

		// シーンをシーン1に設定する。
		asd.Engine.ChangeScene(scene);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
