﻿class Sound_Loop 
{
	public java.lang.String getDescription() {
		return "BGMをループ再生するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "BGMのループ再生";
	}
	public java.lang.String getClassName() {
		return "Sound_Loop";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Sound_Loop", 640, 480, new asd.EngineOption());

		// 音声ファイルを読み込む。BGMの場合、第２引数を false に設定することで、再生しながらファイルを解凍することが推奨されている。
		asd.SoundSource bgm1 = asd.Engine.getSound().CreateSoundSource("Data/Sound/bgm1.ogg", false);

		// 音声のループを有効にする。
		bgm1.setIsLoopingMode(true);

		// 音声のループ始端を1秒に、ループ終端を6秒に設定する。
		bgm1.setLoopStartingPoint(1.0f);
		bgm1.setLoopEndPoint(6.0f);

		// 音声を再生する。
		int id_bgm1 = asd.Engine.getSound().Play(bgm1);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
