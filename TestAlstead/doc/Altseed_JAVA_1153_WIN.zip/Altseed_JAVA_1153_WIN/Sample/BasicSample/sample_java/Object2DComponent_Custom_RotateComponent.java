﻿class Object2DComponent_Custom_RotateComponent extends asd.Object2DComponent
{
	protected void OnUpdate()
	{
		// 毎フレーム、オブジェクトの角度を回転させる
		getOwner().setAngle((getOwner().getAngle() + 2));
	}
}
