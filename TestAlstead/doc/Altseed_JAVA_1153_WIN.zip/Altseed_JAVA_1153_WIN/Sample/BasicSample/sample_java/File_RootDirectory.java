﻿class File_RootDirectory 
{
	public java.lang.String getDescription() {
		return "ファイルを探す際のルートディレクトリを設定する機能のサンプル。";
	}
	public java.lang.String getTitle() {
		return "ルートディレクトリの設定";
	}
	public java.lang.String getClassName() {
		return "File_RootDirectory";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("File_RootDirectory", 640, 480, new asd.EngineOption());

		// ルートディレクトリを追加する。
		asd.Engine.getFile().AddRootDirectory("Data/Texture");

		// オブジェクトを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();

		// 画像を読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Picture1.png");

		// オブジェクトに画像を設定する。
		obj.setTexture(texture);

		// オブジェクトの位置を設定する。
		obj.setPosition(new asd.Vector2DF(100, 100));

		// エンジンにオブジェクトを追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
