﻿class File_StreamFile 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "File_StreamFile";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("File_StreamFile", 640, 480, new asd.EngineOption());

		// フォントを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateFont("Data/Font/Font1.aff");

		// オブジェクトを生成する。
		asd.TextObject2D obj = new asd.TextObject2D();

		// 描画に使うフォントを設定する
		obj.setFont(font);

		// 描画位置を指定する
		obj.setPosition(new asd.Vector2DF(100, 100));

		// ファイルオブジェクト作成
		asd.StreamFile staticFile = asd.Engine.getFile().CreateStreamFile("Data/Text/HelloWorld.txt");

		// ファイルの内容をバッファへ格納
		java.util.ArrayList<java.lang.Byte> buffer = new java.util.ArrayList<java.lang.Byte>();
		staticFile.Read(buffer, 32);

		// UTF-8でバイト列をデコードする
		java.lang.String text = asd.StringHelper.ConvertUTF8(buffer);

		// 描画する文字列の指定
		obj.setText(text);

		// オブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
