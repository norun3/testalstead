﻿/**
 * 画像を変形させて表示するサンプル。
*/
class TextureObject2D_Transform 
{
	public java.lang.String getDescription() {
		return "画像を回転させたり、拡大縮小して描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "画像の変形";
	}
	public java.lang.String getClassName() {
		return "TextureObject2D_Transform";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("TextureObject2D_Transform", 640, 480, new asd.EngineOption());

		// 画像を読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// 画像描画オブジェクトのインスタンスを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();

		// 描画される画像を設定する。
		obj.setTexture(texture);

		// 描画位置を指定する。
		obj.setPosition(new asd.Vector2DF(320, 240));

		// 画像(サイズ 512 x 512)の中心(256 x 256 の地点)を描画の起点とする。
		obj.setCenterPosition(new asd.Vector2DF(256, 256));

		// 中心を軸に画像を45度回転する。
		obj.setAngle(45);

		// 画像をX,Y方向に0.4倍に縮小する。
		obj.setScale(new asd.Vector2DF(0.4f, 0.4f));

		// 画像描画オブジェクトのインスタンスをエンジンに追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
