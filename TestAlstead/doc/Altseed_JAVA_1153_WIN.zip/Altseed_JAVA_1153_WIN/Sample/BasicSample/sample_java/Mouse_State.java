﻿/**
 * マウスの様々な状態を取得するサンプル。
*/
public class Mouse_State 
{
	public java.lang.String getDescription() {
		return "マウスの中ボタンの状態を調べ、状態を表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "マウスボタンの状態";
	}
	public java.lang.String getClassName() {
		return "Mouse_State";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Mouse_State", 640, 480, new asd.EngineOption());

		// マウスの状態を表示するテキストを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 40, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// マウスの中ボタンの入力状態を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D buttonStateText = new asd.TextObject2D();
		buttonStateText.setPosition(new asd.Vector2DF(10, 10));
		buttonStateText.setFont(font);
		asd.Engine.AddObject2D(buttonStateText);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// マウスの中央クリック状態を取得して表示する。

			asd.MouseButtonState middlestate = asd.Engine.getMouse().getMiddleButton().getButtonState();

			if((middlestate == asd.MouseButtonState.Free))
			{
				buttonStateText.setText("中ボタンを離しています。");
			}
			else
			{
				if((middlestate == asd.MouseButtonState.Hold))
				{
					buttonStateText.setText("中ボタンを押しています。");
				}
				else
				{
					if((middlestate == asd.MouseButtonState.Release))
					{
						buttonStateText.setText("中ボタンを離しました!");
					}
					else
					{
						if((middlestate == asd.MouseButtonState.Push))
						{
							buttonStateText.setText("中ボタンを押しました!");
						}
					}
				}
			}

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
