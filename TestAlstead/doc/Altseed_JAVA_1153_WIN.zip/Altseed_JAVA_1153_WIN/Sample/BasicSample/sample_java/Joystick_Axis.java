﻿/**
 * ジョイスティックにある全てのアナログスティックの入力状態を取得するサンプル。
*/
class Joystick_Axis 
{
	public java.lang.String getDescription() {
		return "ジョイスティックのアナログスティックの入力状態を調べ、表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "アナログスティック入力";
	}
	public java.lang.String getClassName() {
		return "Joystick_Axis";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Joystick_Axis", 640, 480, new asd.EngineOption());

		// ジョイスティックの状態を表示するテキストを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 35, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// アナログスティックの入力状態を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D stateText = new asd.TextObject2D();
		stateText.setPosition(new asd.Vector2DF(10, 10));
		stateText.setFont(font);
		asd.Engine.AddObject2D(stateText);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			java.lang.String displayStr = "";

			// ジョイスティックが接続されているかどうかを確認する。
			if(!asd.Engine.getJoystickContainer().GetIsPresentAt(0))
			{
				displayStr += "ジョイスティックが接続されていません。";
			}
			else
			{
				// 1つ目のジョイスティックの全てのアナログスティックの入力状態を表示する。
				asd.Joystick joystick = asd.Engine.getJoystickContainer().GetJoystickAt(0);

				for(int axisIndex = 0; (axisIndex < joystick.getAxesCount()); axisIndex++)
				{
					float axisVal = joystick.GetAxisState(axisIndex);
					displayStr += (("軸 " + axisIndex) + ": ");
					displayStr += axisVal;
					displayStr += "\n";
				}
			}

			stateText.setText(displayStr);

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
