﻿/**
 * キーボードの複数のキーの入力状態を取得するサンプル。
*/
public class Keyboard_PuralKeys 
{
	public java.lang.String getDescription() {
		return "キーボードの複数のキーの入力状態を調べ、表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "複数のキーの入力状態";
	}
	public java.lang.String getClassName() {
		return "Keyboard_PuralKeys";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Keyboard_PuralKeys", 640, 480, new asd.EngineOption());

		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 40, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// キーの入力状態を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D keyStateText = new asd.TextObject2D();
		keyStateText.setPosition(new asd.Vector2DF(10, 10));
		keyStateText.setFont(font);
		asd.Engine.AddObject2D(keyStateText);

		// 入力チェックするキー一覧。(Z, X, C, V, B)
		java.util.ArrayList<asd.Keys> keys = new java.util.ArrayList<asd.Keys>();
		keys.add(asd.Keys.Z);
		keys.add(asd.Keys.X);
		keys.add(asd.Keys.C);
		keys.add(asd.Keys.V);
		keys.add(asd.Keys.B);

		// キーの文字列表現。
		java.util.ArrayList<java.lang.String> keyStrs = new java.util.ArrayList<java.lang.String>();
		keyStrs.add("Z");
		keyStrs.add("X");
		keyStrs.add("C");
		keyStrs.add("V");
		keyStrs.add("B");

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			java.lang.String displayStr = "";

			// すべてのキーに対して入力状態を確認してから表示する。
			for(int i = 0; (i < keys.size()); i++)
			{
				java.lang.String keystr = keyStrs.get(i);

				// キーボードのZキーの入力状態を取得する。
				asd.KeyState state = asd.Engine.getKeyboard().GetKeyState(keys.get(i));

				if((state == asd.KeyState.Free))
				{
					displayStr += (keystr + "キーを離しています。");
				}
				else
				{
					if((state == asd.KeyState.Hold))
					{
						displayStr += (keystr + "キーを押しています。");
					}
					else
					{
						if((state == asd.KeyState.Release))
						{
							displayStr += (keystr + "キーを離しました!");
						}
						else
						{
							if((state == asd.KeyState.Push))
							{
								displayStr += (keystr + "キーを押しました!");
							}
						}
					}
				}

				displayStr += "\n";
			}

			// キー入力状態を示す文字列を更新する。
			keyStateText.setText(displayStr);

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
