﻿/**
 * 弧を表示するサンプル。
*/
class GeometryObject2D_ArcShape 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "GeometryObject2D_ArcShape";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("GeometryObject2D_ArcShape", 640, 480, new asd.EngineOption());

		// 図形描画クラスのコンストラクタを呼び出す。
		asd.GeometryObject2D geometryObj = new asd.GeometryObject2D();

		// 図形描画オブジェクトのインスタンスをエンジンに追加する。
		asd.Engine.AddObject2D(geometryObj);

		// 弧の図形クラスのインスタンスを生成する。
		asd.ArcShape arc = new asd.ArcShape();

		// 弧の外径、内径、頂点数、中心位置、開始頂点番号、終了頂点番号を指定する。
		arc.setOuterDiameter(400);
		arc.setInnerDiameter(40);
		arc.setNumberOfCorners(96);
		arc.setPosition(new asd.Vector2DF(320, 240));
		arc.setStartingCorner(90);
		arc.setEndingCorner(45);

		// 弧を描画する図形として設定する。
		geometryObj.setShape(arc);

		// Altseedを更新する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
