﻿class Basic_FullScreen 
{
	public java.lang.String getDescription() {
		return "アプリケーションをフルスクリーンで起動するサンプル。";
	}
	public java.lang.String getTitle() {
		return "フルスクリーンモード";
	}
	public java.lang.String getClassName() {
		return "Basic_FullScreen";
	}
	public static void main(String args[])
	{
		// フルスクリーンで起動するように初期化オプションを生成する。
		asd.EngineOption option = new asd.EngineOption();
		option.IsFullScreen = true;

		// 作成した初期化オプションを用いてAltseedを初期化する。
		asd.Engine.Initialize("Empty", 640, 480, option);

		// 操作説明文を文字列オブジェクトとして作成。CreateDynamicFontで作成したフォントオブジェクトを用いる
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 20, new asd.Color(255, 255, 255), 2, new asd.Color(0, 0, 0));
		asd.TextObject2D obj = new asd.TextObject2D();
		obj.setFont(font);
		obj.setText("Escキーで終了");

		// 操作説明文のオブジェクトをエンジンに登録する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();

			// Escキーが押されていたら
			if((asd.Engine.getKeyboard().GetKeyState(asd.Keys.Escape) == asd.KeyState.Push))
			{
				// ゲームループを抜ける
				break;
			}
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
