﻿/**
 * 文字列を表示するサンプル。
*/
class TextObject2D_Basic 
{
	public java.lang.String getDescription() {
		return "文字列を描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "文字列の描画";
	}
	public java.lang.String getClassName() {
		return "TextObject2D_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("TextObject2D_Basic", 640, 480, new asd.EngineOption());

		// フォントを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateFont("Data/Font/Font1.aff");

		// 文字描画オブジェクトを生成する。
		asd.TextObject2D obj = new asd.TextObject2D();

		// 描画に使うフォントを設定する。
		obj.setFont(font);

		// 描画位置を指定する。
		obj.setPosition(new asd.Vector2DF(100, 100));

		// 描画する文字列を指定する。
		obj.setText("普通の文字列描画");

		// 文字描画オブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
