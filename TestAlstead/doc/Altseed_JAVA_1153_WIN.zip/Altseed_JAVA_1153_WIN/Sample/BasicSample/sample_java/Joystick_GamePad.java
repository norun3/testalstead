﻿/**
 * 一部のゲームパッドから入力状態を取得するサンプル。
*/
class Joystick_GamePad 
{
	public java.lang.String getDescription() {
		return "一部のゲームパッドの入力状態を調べ、表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "ゲームパッド入力";
	}
	public java.lang.String getClassName() {
		return "Joystick_GamePad";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Joystick_GamePad", 640, 480, new asd.EngineOption());

		// ジョイスティックの状態を表示するテキストを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 25, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// ボタンの入力状態を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D stateText = new asd.TextObject2D();
		stateText.setPosition(new asd.Vector2DF(10, 5));
		stateText.setFont(font);
		asd.Engine.AddObject2D(stateText);

		// ボタンをたくさん認識する可能性があるため表示の行間を詰める。
		stateText.setLineSpacing(-15);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			java.lang.String displayStr = "";

			// ジョイスティックが接続されているかどうかを確認する。
			if(!asd.Engine.getJoystickContainer().GetIsPresentAt(0))
			{
				displayStr += "ジョイスティックが接続されていません。";
			}
			else
			{
				if((asd.Engine.getJoystickContainer().GetJoystickAt(0).getJoystickType() == asd.JoystickType.Other))
				{
					displayStr += "認識できないジョイステイックです。";
				}
				else
				{
					// 1つ目のジョイスティックのボタンの入力状態を表示する。
					// RightRightはPSの場合〇、XBOXの場合、Bボタンを示す。
					asd.Joystick joystick = asd.Engine.getJoystickContainer().GetJoystickAt(0);

					asd.JoystickButtonState state = joystick.GetButtonStateAt(asd.JoystickButtonType.RightRight);
					if((state == asd.JoystickButtonState.Free))
					{
						displayStr += "ボタンを離しています。";
					}
					else
					{
						if((state == asd.JoystickButtonState.Hold))
						{
							displayStr += "ボタンを押しています。";
						}
						else
						{
							if((state == asd.JoystickButtonState.Release))
							{
								displayStr += "ボタンを離しました!";
							}
							else
							{
								if((state == asd.JoystickButtonState.Push))
								{
									displayStr += "ボタンを押しました!";
								}
							}
						}
					}
				}
			}

			stateText.setText(displayStr);

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
