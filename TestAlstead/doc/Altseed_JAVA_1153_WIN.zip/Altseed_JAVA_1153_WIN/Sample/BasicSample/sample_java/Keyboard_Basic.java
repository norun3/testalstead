﻿/**
 * キーボードによる入力を取得するサンプル。
*/
public class Keyboard_Basic 
{
	public java.lang.String getDescription() {
		return "Zキーを押しているかどうかを調べ、結果を表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "キーボード入力の基本";
	}
	public java.lang.String getClassName() {
		return "Keyboard_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Keyboard_Basic", 640, 480, new asd.EngineOption());

		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 40, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// キーの入力状態を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D keyStateText = new asd.TextObject2D();
		keyStateText.setPosition(new asd.Vector2DF(10, 10));
		keyStateText.setFont(font);
		asd.Engine.AddObject2D(keyStateText);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// キーボードのZキーの入力状態を取得する。

			asd.KeyState zstate = asd.Engine.getKeyboard().GetKeyState(asd.Keys.Z);

			if((zstate == asd.KeyState.Free))
			{
				keyStateText.setText("Zキーを離しています。");
			}
			else
			{
				if((zstate == asd.KeyState.Hold))
				{
					keyStateText.setText("Zキーを押しています。");
				}
			}

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
