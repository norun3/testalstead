﻿class Object2DComponent_Custom 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "Object2DComponent_Custom";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Object2DComponent_Custom", 640, 480, new asd.EngineOption());

		// オブジェクトを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();

		// 画像を読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// オブジェクトに画像を設定する。
		obj.setTexture(texture);

		// オブジェクトの位置を設定する。
		obj.setPosition(new asd.Vector2DF(320, 240));

		// エンジンにオブジェクトを追加する。
		asd.Engine.AddObject2D(obj);

		// 回転コンポーネントを生成する。
		Object2DComponent_Custom_RotateComponent component = new Object2DComponent_Custom_RotateComponent();

		// オブジェクトに回転コンポーネントをコンポーネント名"Rotate"で追加する。
		obj.AddComponent(component, "Rotate");

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
