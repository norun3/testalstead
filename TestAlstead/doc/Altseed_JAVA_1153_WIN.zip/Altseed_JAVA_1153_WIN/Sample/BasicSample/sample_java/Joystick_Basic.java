﻿/**
 * ジョイスティックにある全てのボタンの入力状態を取得するサンプル。
*/
class Joystick_Basic 
{
	public java.lang.String getDescription() {
		return "ジョイスティックのボタンの入力状態を調べ、表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "ジョイスティックのボタン入力";
	}
	public java.lang.String getClassName() {
		return "Joystick_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Joystick_Basic", 640, 480, new asd.EngineOption());

		// ジョイスティックの状態を表示するテキストを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 25, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// ボタンの入力状態を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D stateText = new asd.TextObject2D();
		stateText.setPosition(new asd.Vector2DF(10, 5));
		stateText.setFont(font);
		asd.Engine.AddObject2D(stateText);

		// ボタンをたくさん認識する可能性があるため表示の行間を詰める。
		stateText.setLineSpacing(-15);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			java.lang.String displayStr = "";

			// ジョイスティックが接続されているかどうかを確認する。
			if(!asd.Engine.getJoystickContainer().GetIsPresentAt(0))
			{
				displayStr += "ジョイスティックが接続されていません。";
			}
			else
			{
				// 1つ目のジョイスティックの全てのボタンの入力状態を表示する。
				asd.Joystick joystick = asd.Engine.getJoystickContainer().GetJoystickAt(0);

				for(int buttonIndex = 0; (buttonIndex < joystick.getButtonsCount()); buttonIndex++)
				{
					asd.JoystickButtonState state = joystick.GetButtonState(buttonIndex);

					if((state == asd.JoystickButtonState.Free))
					{
						displayStr += (("ボタン " + buttonIndex) + "を離しています。");
					}
					else
					{
						if((state == asd.JoystickButtonState.Hold))
						{
							displayStr += (("ボタン " + buttonIndex) + "を押しています。");
						}
						else
						{
							if((state == asd.JoystickButtonState.Release))
							{
								displayStr += (("ボタン " + buttonIndex) + "を離しました!");
							}
							else
							{
								if((state == asd.JoystickButtonState.Push))
								{
									displayStr += (("ボタン " + buttonIndex) + "を押しました!");
								}
							}
						}
					}

					displayStr += "\n";
				}
			}

			stateText.setText(displayStr);

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
