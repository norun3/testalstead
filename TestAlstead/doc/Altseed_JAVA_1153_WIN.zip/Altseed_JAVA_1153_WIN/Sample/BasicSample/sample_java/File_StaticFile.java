﻿class File_StaticFile 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "File_StaticFile";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("File_StaticFile", 640, 480, new asd.EngineOption());

		// フォントを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateFont("Data/Font/Font1.aff");

		// オブジェクトを生成する。
		asd.TextObject2D obj = new asd.TextObject2D();

		// 描画に使うフォントを設定する
		obj.setFont(font);

		// 描画位置を指定する
		obj.setPosition(new asd.Vector2DF(100, 100));

		// ファイルオブジェクト作成
		asd.StaticFile staticFile = asd.Engine.getFile().CreateStaticFile("Data/Text/HelloWorld.txt");

		// 描画したいテキストのバイト列をファイルから読み取る
		byte[] textBytes = staticFile.getBuffer();

		// UTF-8でバイト列をデコードする
		java.lang.String text = asd.StringHelper.ConvertUTF8(textBytes);

		// 描画する文字列の指定
		obj.setText(text);

		// オブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
