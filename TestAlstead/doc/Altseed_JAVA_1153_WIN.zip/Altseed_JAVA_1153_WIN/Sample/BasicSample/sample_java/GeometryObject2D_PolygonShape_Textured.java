﻿/**
 * 多角形をテクスチャを合成した上で表示するサンプル。
*/
class GeometryObject2D_PolygonShape_Textured 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "GeometryObject2D_PolygonShape_Textured";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("GeometryObject2D_PolygonShape_Textured", 640, 480, new asd.EngineOption());

		// テクスチャとして図形に合成する画像を読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Sample1.png");

		// 図形描画オブジェクトのインスタンスを生成する。
		asd.GeometryObject2D geometryObj = new asd.GeometryObject2D();

		// 図形描画オブジェクトのインスタンスをエンジンに追加する。
		asd.Engine.AddObject2D(geometryObj);

		// 多角形の図形クラスのインスタンスを生成する。
		asd.PolygonShape polygon = new asd.PolygonShape();

		// 多角形を構成する頂点を追加していく。（星形になるようにする。）
		for(int i = 0; (i < 10); i++)
		{
			asd.Vector2DF vec = new asd.Vector2DF(1, 0);
			vec.setDegree((i * 36));

			if(((i % 2 ) == 0))
			{
				vec.setLength(200);
			}
			else
			{
				vec.setLength(75);
			}

			polygon.AddVertex(asd.Vector2DF.Add(vec, new asd.Vector2DF(320, 240)));
		}

		// 多角形を描画する図形として設定し、合成するテクスチャも設定する。
		geometryObj.setShape(polygon);
		geometryObj.setTexture(texture);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
