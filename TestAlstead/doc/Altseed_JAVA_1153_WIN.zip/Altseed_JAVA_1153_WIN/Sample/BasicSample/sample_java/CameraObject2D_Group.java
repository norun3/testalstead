﻿/**
 * カメラに特定のオブジェクトのみを表示する。
*/
public class CameraObject2D_Group 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "CameraObject2D_Group";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("CameraObject2D_Group", 640, 480, new asd.EngineOption());

		// 画像を読み込む。
		asd.Texture2D tex = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// テクスチャを描画するオブジェクトを設定する。
		asd.TextureObject2D obj1 = new asd.TextureObject2D();
		obj1.setTexture(tex);
		obj1.setPosition(new asd.Vector2DF(10, 10));
		obj1.setScale(new asd.Vector2DF(0.5f, 0.5f));

		// グループを設定する。(描画されない)
		obj1.setCameraGroup(1);
		asd.Engine.AddObject2D(obj1);

		// テクスチャを描画するオブジェクトを設定する。
		asd.TextureObject2D obj2 = new asd.TextureObject2D();
		obj2.setTexture(tex);
		obj2.setPosition(new asd.Vector2DF(310, 10));
		obj2.setScale(new asd.Vector2DF(0.5f, 0.5f));

		// グループを設定する。
		obj2.setCameraGroup(2);
		asd.Engine.AddObject2D(obj2);

		// カメラを設定する。
		asd.CameraObject2D camera = new asd.CameraObject2D();
		camera.setSrc(new asd.RectI(0, 0, 640, 480));
		camera.setDst(new asd.RectI(0, 0, 640, 480));

		// グループを設定する。
		camera.setCameraGroup(2);
		asd.Engine.AddObject2D(camera);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
