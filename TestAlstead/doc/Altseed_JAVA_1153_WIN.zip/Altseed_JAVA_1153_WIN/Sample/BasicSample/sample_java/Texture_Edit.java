﻿/**
 * 読み込まれた画像を編集するサンプル
*/
class Texture_Edit 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "Texture_Edit";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Texture_Edit", 640, 480, new asd.EngineOption());

		// 画像を編集可能な状態で読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateEditableTexture2D("Data/Texture/Picture1.png");

		// ロックして編集可能な状態にする。
		asd.TextureLockInfomation lockInfo = new asd.TextureLockInfomation();
		if(texture.Lock(lockInfo))
		{











			System.out.println("実装されていません。");

			// Unlockして編集結果を適用する。
			texture.Unlock();
		}


		// 画像描画オブジェクトのインスタンスを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();

		// 描画される画像を設定する。
		obj.setTexture(texture);

		// 描画位置を指定する。
		obj.setPosition(new asd.Vector2DF(50, 50));

		// 画像描画オブジェクトのインスタンスをエンジンに追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
