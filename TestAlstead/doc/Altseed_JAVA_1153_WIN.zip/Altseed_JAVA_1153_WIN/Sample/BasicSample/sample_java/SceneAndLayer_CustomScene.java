﻿class SceneAndLayer_CustomScene 
{
	public java.lang.String getDescription() {
		return "Sceneクラスを継承して、ふるまいをカスタマイズするサンプル。";
	}
	public java.lang.String getTitle() {
		return "シーンのカスタマイズ";
	}
	public java.lang.String getClassName() {
		return "SceneAndLayer_CustomScene";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("SceneAndLayer_CustomScene", 640, 480, new asd.EngineOption());

		// シーンクラスのインスタンスを生成する。
		SceneAndLayer_SampleScene scene = new SceneAndLayer_SampleScene();

		// 描画するシーンを指定する。
		asd.Engine.ChangeScene(scene);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
