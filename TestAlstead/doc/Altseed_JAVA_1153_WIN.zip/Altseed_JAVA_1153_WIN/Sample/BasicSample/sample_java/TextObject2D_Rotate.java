﻿/**
 * 文字列を回転させて表示するサンプル。
*/
class TextObject2D_Rotate 
{
	public java.lang.String getDescription() {
		return "文字列を回転させて描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "文字列の回転";
	}
	public java.lang.String getClassName() {
		return "TextObject2D_Rotate";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("TextObject2D_Rotate", 640, 480, new asd.EngineOption());

		// フォントと文字列描画オブジェクトの設定を行う。
		asd.Font edgeFont = asd.Engine.getGraphics().CreateFont("Data/Font/Font1.aff");
		asd.TextObject2D edgeObj = new asd.TextObject2D();
		edgeObj.setFont(edgeFont);
		edgeObj.setPosition(new asd.Vector2DF(100, 100));

		// 回転角と描画する文字列を設定する。
		edgeObj.setAngle(30);
		edgeObj.setText("文字列の回転描画");

		// 文字描画オブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(edgeObj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
