﻿class SceneAndLayer_CustomLayer 
{
	public java.lang.String getDescription() {
		return "Layer2Dクラスを継承して、ふるまいをカスタマイズするサンプル。";
	}
	public java.lang.String getTitle() {
		return "レイヤーのカスタマイズ";
	}
	public java.lang.String getClassName() {
		return "SceneAndLayer_CustomLayer";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("SceneAndLayer_CustomLayer", 640, 480, new asd.EngineOption());

		// シーンクラスのインスタンスを生成する。
		asd.Scene scene = new asd.Scene();

		// 描画するシーンを指定する。
		asd.Engine.ChangeScene(scene);

		// レイヤークラスのインスタンスを生成する。
		SceneAndLayer_SampleLayer layer = new SceneAndLayer_SampleLayer();

		// 描画するレイヤーをシーンに追加する。
		scene.AddLayer(layer);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
