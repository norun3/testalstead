﻿class EngineMisc_ShowFps 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "EngineMisc_ShowFps";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("EngineMisc_ShowFps", 640, 480, new asd.EngineOption());

		// 動的フォントを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 32, new asd.Color(255, 255, 255, 255), 1, new asd.Color(255, 255, 255, 255));

		// FPSを表示するためのオブジェクトを生成する。
		asd.TextObject2D obj = new asd.TextObject2D();
		obj.setFont(font);

		// オブジェクトをエンジンに追加する。
		asd.Engine.AddObject2D(obj);

		while(asd.Engine.DoEvents())
		{
			asd.Engine.Update();

			// 現在のFPSを取得する。
			float fps = asd.Engine.getCurrentFPS();

			// 表示する文字列を生成する。
			java.lang.String str = ("FPS : " + fps);

			// 文字列をオブジェクトに設定する。
			obj.setText(str);

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
