﻿class Sound_SE 
{
	public java.lang.String getDescription() {
		return "効果音(Sound Effect)を再生するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "効果音の再生";
	}
	public java.lang.String getClassName() {
		return "Sound_SE";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Sound_SE", 640, 480, new asd.EngineOption());

		// 音ファイルを読み込む。SEの場合、第２引数を true に設定することで、この場でファイルを解凍することが推奨されている。
		asd.SoundSource se1 = asd.Engine.getSound().CreateSoundSource("Data/Sound/se1.wav", true);

		// 音を再生する。
		int id_se1 = asd.Engine.getSound().Play(se1);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();

			// 音が再生終了してるか調べる。
			if(!asd.Engine.getSound().GetIsPlaying(id_se1))
			{
				break;
			}
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
