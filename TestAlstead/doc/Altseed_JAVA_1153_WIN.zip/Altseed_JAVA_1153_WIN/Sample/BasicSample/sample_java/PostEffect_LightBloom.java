﻿class PostEffect_LightBloom 
{
	public java.lang.String getDescription() {
		return "レイヤーの描画結果にライトブルーム効果をかけるサンプル。";
	}
	public java.lang.String getTitle() {
		return "ライトブルーム";
	}
	public java.lang.String getClassName() {
		return "PostEffect_LightBloom";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("PostEffect_LightBloom", 640, 480, new asd.EngineOption());

		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// シーンクラスのインスタンスを生成する。
		asd.Scene scene = new asd.Scene();

		// レイヤーのコンストラクタを呼び出す。
		asd.Layer2D layer = new asd.Layer2D();

		// レイヤークラスのインスタンスを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();

		// 画像描画オブジェクトのインスタンスを生成する。
		obj.setPosition(new asd.Vector2DF(50, 50));
		obj.setTexture(texture);

		// シーンを変更し、そのシーンにレイヤーを追加し、そのレイヤーにオブジェクトを追加する。
		asd.Engine.ChangeScene(scene);
		scene.AddLayer(layer);
		layer.AddObject(obj);

		// ライトブルームクラスのインスタンスを生成する。
		asd.PostEffectLightBloom posteffect = new asd.PostEffectLightBloom();

		// ライトブルームのぼかしの強さを設定する。
		posteffect.setIntensity(10.0f);

		// ライトブルームの露光の強さを設定する。
		posteffect.setExposure(1.0f);

		// ライトブルームで光らせる明るさのしきい値を設定する。
		posteffect.setThreshold(0.3f);

		// レイヤーにライトブルームのポストエフェクトを適用。
		layer.AddPostEffect(posteffect);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
