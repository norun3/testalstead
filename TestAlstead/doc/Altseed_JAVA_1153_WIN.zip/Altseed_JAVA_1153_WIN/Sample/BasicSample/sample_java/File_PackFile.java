﻿class File_PackFile 
{
	public java.lang.String getDescription() {
		return "Altseedのパッケージ機能でパッケージにまとめたファイルにアクセスするサンプル。";
	}
	public java.lang.String getTitle() {
		return "パッケージからのファイル読み込み";
	}
	public java.lang.String getClassName() {
		return "File_PackFile";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("File_PackFile", 640, 480, new asd.EngineOption());

		// パッケージをルートディレクトリに追加する。
		asd.Engine.getFile().AddRootDirectory("Data.pack");

		// オブジェクトを生成する。
		asd.TextureObject2D obj = new asd.TextureObject2D();

		// パッケージ内の画像を読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Texture/Picture1.png");

		// オブジェクトに画像を設定する。
		obj.setTexture(texture);

		// オブジェクトの位置を設定する。
		obj.setPosition(new asd.Vector2DF(100, 100));

		// エンジンにオブジェクトを追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
