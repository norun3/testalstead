﻿/**
 * Collision2Dのサンプル1。マウスによって操作する円が固定された円にヒットしたら円が赤く変化します。
*/
public class Collision2D_Basic 
{
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getClassName() {
		return "Collision2D_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Collision2D_Basic", 640, 480, new asd.EngineOption());

		// 図形描画オブジェクトのインスタンスを生成する。
		asd.GeometryObject2D geometryObj0 = new asd.GeometryObject2D();
		asd.GeometryObject2D geometryObj1 = new asd.GeometryObject2D();

		// マウスによって動かす円。
		asd.CircleShape selfCircle = null;

		// 停止している円。
		asd.CircleShape circle = null;

		// 図形描画オブジェクトをエンジンに追加する。
		asd.Engine.AddObject2D(geometryObj0);
		asd.Engine.AddObject2D(geometryObj1);

		// マウスによって動かす円の形状と描画の設定を行う。
		// マウスによって動かす円の形状と描画の設定を行う。

		// 円の外径を指定する。
		selfCircle = new asd.CircleShape();
		selfCircle.setOuterDiameter(100);

		// マウスによって動かす円を描画する図形として設定する。
		geometryObj0.setShape(selfCircle);

		// 停止している円の形状と描画の設定を行う。
		// 停止している円の形状と描画の設定を行う。

		// 円の外径、内径、頂点数、中心位置を指定する。
		circle = new asd.CircleShape();
		circle.setOuterDiameter(100);
		circle.setPosition(new asd.Vector2DF(100, 100));

		// 停止している円を描画する図形として設定する。
		geometryObj1.setShape(circle);


		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// マウスによって制御される円の中心位置をマウスの位置とする。
			selfCircle.setPosition(asd.Engine.getMouse().getPosition());

			// 固定されている円に、マウスによって動く円が衝突した時に円を赤く変化させる。
			// そうでない時は白く変化させる。
			if(selfCircle.GetIsCollidedWith(circle))
			{
				geometryObj0.setColor(new asd.Color(255, 0, 0, 255));
			}
			else
			{
				geometryObj0.setColor(new asd.Color(255, 255, 255, 255));
			}


			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
