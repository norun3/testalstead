﻿class Dispose_Layer2D_MessageObject extends asd.TextureObject2D
{
	protected void OnDispose()
	{
		System.out.println("MessageObject.OnDispose");
	}
}
