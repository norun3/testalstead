﻿/**
 * カメラを用いた描画空間の一部を切り取って描画するサンプルを表示する。
*/
public class CameraObject2D_Basic 
{
	public java.lang.String getDescription() {
		return "カメラを用いて描画空間の一部を切り取って描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "カメラの基本";
	}
	public java.lang.String getClassName() {
		return "CameraObject2D_Basic";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("CameraObject2D_Basic", 640, 480, new asd.EngineOption());

		// 画像を読み込む。
		asd.Texture2D tex0 = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// テクスチャを描画するオブジェクトを設定する。
		asd.TextureObject2D obj0 = new asd.TextureObject2D();
		obj0.setTexture(tex0);
		obj0.setPosition(new asd.Vector2DF(10, 10));
		obj0.setScale(new asd.Vector2DF(0.7f, 0.7f));
		asd.Engine.AddObject2D(obj0);

		// 画面全体を写すカメラを設定する。(オブジェクトをそのまま描画する。)
		asd.CameraObject2D entityCamera = new asd.CameraObject2D();
		entityCamera.setSrc(new asd.RectI(0, 0, 640, 480));
		entityCamera.setDst(new asd.RectI(0, 0, 640, 480));
		asd.Engine.AddObject2D(entityCamera);

		// テクスチャの左上から縦横150ピクセルを切り取って描画するカメラを設定する。
		asd.CameraObject2D camera = new asd.CameraObject2D();
		camera.setSrc(new asd.RectI(10, 10, 150, 150));
		camera.setDst(new asd.RectI(450, 10, 150, 150));
		asd.Engine.AddObject2D(camera);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
