﻿/**
 * マウスによる入力を取得を取得するサンプル。
*/
public class Mouse_Click 
{
	public java.lang.String getDescription() {
		return "マウスの左クリックを検知するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "マウスのクリック検知";
	}
	public java.lang.String getClassName() {
		return "Mouse_Click";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Mouse_Click", 640, 480, new asd.EngineOption());

		// マウスの状態を表示するテキストを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 40, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// マウスの左ボタンをクリックしたか否かを表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D stateText = new asd.TextObject2D();
		stateText.setPosition(new asd.Vector2DF(10, 10));
		stateText.setFont(font);
		asd.Engine.AddObject2D(stateText);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// 左ボタンが押されているかを表示する。
			if((asd.Engine.getMouse().getLeftButton().getButtonState() == asd.MouseButtonState.Hold))
			{
				stateText.setText("左ボタンが押されています。");
			}
			else
			{
				stateText.setText("左ボタンが押されていません。");
			}

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
