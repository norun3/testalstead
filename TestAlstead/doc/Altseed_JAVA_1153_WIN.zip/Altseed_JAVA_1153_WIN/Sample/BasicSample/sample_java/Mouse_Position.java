﻿/**
 * マウスの座標を取得を取得するサンプル。
*/
public class Mouse_Position 
{
	public java.lang.String getDescription() {
		return "マウスの座標を取得し、その位置を表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "マウス座標の取得";
	}
	public java.lang.String getClassName() {
		return "Mouse_Position";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Mouse_Position", 640, 480, new asd.EngineOption());

		// マウスの状態を表示するテキストを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 25, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// マウスカーソルの座標を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D stateText = new asd.TextObject2D();
		stateText.setPosition(new asd.Vector2DF(10, 10));
		stateText.setFont(font);
		asd.Engine.AddObject2D(stateText);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// マウスカーソルの座標を取得して表示する。
			asd.Vector2DF pos = asd.Engine.getMouse().getPosition();
			stateText.setText((((("マウスカーソルの位置 : (" + pos.X) + ",") + pos.Y) + ")"));

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
