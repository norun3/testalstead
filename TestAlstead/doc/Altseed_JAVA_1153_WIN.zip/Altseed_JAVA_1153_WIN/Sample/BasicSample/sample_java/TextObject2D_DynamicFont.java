﻿/**
 * 文字列を表示するサンプル。
*/
class TextObject2D_DynamicFont 
{
	public java.lang.String getDescription() {
		return "フォントをプログラム実行中にに準備して、そのフォントで文字列を描画するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "フォントの動的生成";
	}
	public java.lang.String getClassName() {
		return "TextObject2D_DynamicFont";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("TextObject2D_DynamicFont", 640, 480, new asd.EngineOption());

		// 動的フォントを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 35, new asd.Color(255, 0, 0, 255), 1, new asd.Color(255, 255, 255, 255));

		// 文字描画オブジェクトを生成する。
		asd.TextObject2D obj = new asd.TextObject2D();

		// 描画に使うフォントを設定する。
		obj.setFont(font);

		// 描画位置を指定する。
		obj.setPosition(new asd.Vector2DF(100, 100));

		// 描画する文字列を指定する。
		obj.setText("動的フォントによる文字列描画");

		// 文字描画オブジェクトのインスタンスをエンジンへ追加する。
		asd.Engine.AddObject2D(obj);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();
		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
