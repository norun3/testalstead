﻿/**
 * マウスのホイールの回転度合を取得するサンプル。
*/
public class Mouse_Wheel 
{
	public java.lang.String getDescription() {
		return "マウスホイールの回転の度合いを調べ、表示するサンプルです。";
	}
	public java.lang.String getTitle() {
		return "マウスホイール";
	}
	public java.lang.String getClassName() {
		return "Mouse_Wheel";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Mouse_Wheel", 640, 480, new asd.EngineOption());

		// マウスの状態を表示するテキストを生成する。
		asd.Font font = asd.Engine.getGraphics().CreateDynamicFont("", 40, new asd.Color(255, 255, 255, 255), 1, new asd.Color(0, 0, 0, 255));

		// マウスのホイールの回転度合を表示する文字描画オブジェクトを設定して、エンジンに追加する。
		asd.TextObject2D wheelStateText = new asd.TextObject2D();
		wheelStateText.setPosition(new asd.Vector2DF(10, 10));
		wheelStateText.setFont(font);
		asd.Engine.AddObject2D(wheelStateText);

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// マウスのホイールの回転状態を取得して表示する。
			wheelStateText.setText(("ホイールの回転度合 : " + asd.Engine.getMouse().getMiddleButton().getWheelRotation()));

			// Altseedを更新する。
			asd.Engine.Update();

		}
		

		// Altseedの終了処理をする。
		asd.Engine.Terminate();
	}
}
