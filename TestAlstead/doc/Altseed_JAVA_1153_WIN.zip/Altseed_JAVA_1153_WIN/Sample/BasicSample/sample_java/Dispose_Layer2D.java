﻿class Dispose_Layer2D 
{
	public java.lang.String getDescription() {
		return "";
	}
	public java.lang.String getTitle() {
		return "";
	}
	public java.lang.String getClassName() {
		return "Dispose_Layer2D";
	}
	public static void main(String args[])
	{
		// Altseedを初期化する。
		asd.Engine.Initialize("Dispose_Object2D", 640, 480, new asd.EngineOption());

		// 画像を読み込む。
		asd.Texture2D texture = asd.Engine.getGraphics().CreateTexture2D("Data/Texture/Picture1.png");

		// シーンのインスタンスを生成する。
		asd.Scene scene = new asd.Scene();

		// カスタマイズしたレイヤーのインスタンスを生成する。
		Dispose_Layer2D_MessageLayer layer = new Dispose_Layer2D_MessageLayer();

		// カスタマイズしたオブジェクトのインスタンスを生成する。
		Dispose_Layer2D_MessageObject obj = new Dispose_Layer2D_MessageObject();

		// オブジェクトの位置とテクスチャを設定する。
		obj.setPosition(new asd.Vector2DF(50, 50));
		obj.setTexture(texture);

		// 描画するシーンを指定する。
		asd.Engine.ChangeScene(scene);

		// 描画するレイヤーをシーンに追加する。
		scene.AddLayer(layer);

		// 描画するオブジェクトをレイヤーに追加する。
		layer.AddObject(obj);

		// フレーム数を数えるための変数。
		int count = 0;

		// Altseedのウインドウが閉じられていないか確認する。
		while(asd.Engine.DoEvents())
		{
			// Altseedを更新する。
			asd.Engine.Update();

			// フレームを数える。
			count++;

			// 10フレーム目になったら
			if((count == 10))
			{
				System.out.println("Layerを破棄します");
				// レイヤーを破棄する。
				layer.Dispose();
			}
		}
		

		// Altseedを終了する。
		asd.Engine.Terminate();
	}
}
